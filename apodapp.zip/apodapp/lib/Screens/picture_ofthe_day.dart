// ignore_for_file: prefer_const_constructors, avoid_unnecessary_containers, prefer_const_constructors_in_immutables
import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'dart:convert';

class PictureoftheDay extends StatefulWidget {
  static const routeName = '/POD';

  PictureoftheDay({Key? key}) : super(key: key);

  @override
  State<PictureoftheDay> createState() => _PictureoftheDayState();
}

class _PictureoftheDayState extends State<PictureoftheDay> {
  String imageUrl='';
  String imageInfo = '';
  String imageTitle = '';
  String mediaType= '';

  apodResponse() async {
    String url ="https://api.nasa.gov/planetary/apod?api_key=MScNtCusRYrWdIqiFDAspqlYs0LHHk7QBMaQzwug";
    final response = await get(Uri.parse(Uri.encodeFull(url)));
    var jasonData = jsonDecode(response.body);

    setState(() {
      imageInfo=jasonData['explanation']==null?"data is not available":jasonData["explanation"];
      imageTitle=jasonData['title'] ?? "data is not available";
      mediaType=jasonData['media_type'];
      if(mediaType=="image"){  imageUrl=jasonData['hdurl'];}
      else {imageUrl='';}
    });
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: CircleAvatar(backgroundColor: Colors.purple,)
            ),
            ListTile(
              leading: Icon(Icons.phone, size: 40,),
              title: Text('Phone Number'),
              subtitle: Text("7743848037"),
              trailing: Icon(Icons.more_vert),
              onTap: () {
              },
            ),
            ListTile(
              leading: Icon(Icons.bathroom,size: 40,),
              title: Text('Github Hyperlink'),
              subtitle: Text("Github.com"),
              trailing: Icon(Icons.more_vert),
              onTap: () {
              },
            ),
            ListTile(
              leading: Icon(Icons.linked_camera_outlined, size: 40,),
              title: Text('Linkdin'),
              subtitle: Text("This is the 1st item"),
              trailing: Icon(Icons.more_vert),
              onTap: () {
              },
            ),
          ],
        ),
      ),
      appBar:  AppBar(
        title: Text('APOD'),
      ),
      body:
          imageUrl == '' ?
          Center(
            child: FlatButton(
              onPressed: apodResponse,
              child: Container(
                width:200,
                height: 100,

                padding: EdgeInsets.fromLTRB(5,20,5,20),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(50),
                ),
                alignment: Alignment.center,
                child: Text(
                  'Show Information',
                  style: TextStyle(
                    color:Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.bold
                  ),
                ),
              ),
            ),
          ):ListView(children: [
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
              alignment: Alignment.center,
              child: Text(imageTitle,
              style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
              ),
              ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 10),
              child: ClipRRect(
                child: Image.network(imageUrl,
                    ),
                borderRadius: BorderRadius.circular(30),    
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
              alignment: Alignment.center,
              child: Text('Media Type : $mediaType ',
              style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
              ),
              ),       

            Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              child: 
              Text(
                'Image Elaboration :\n\t\t\t ',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold

                  ),),),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              child: 
              Text(
                imageInfo,
                style: TextStyle(
                  fontSize: 20,

                  ),),),   

          ],)
      
    );
  }
}