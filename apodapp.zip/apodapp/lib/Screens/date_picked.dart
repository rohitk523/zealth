// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, avoid_print
import 'package:apodapp/Screens/picture_ofthe_day.dart';
import 'package:flutter/material.dart';



class DatePicked extends StatefulWidget {
  const DatePicked({ Key? key }) : super(key: key);

  @override
  _DatePickedState createState() => _DatePickedState();
}

class _DatePickedState extends State<DatePicked> {
  DateTime? dateTime;
  String? year;
  String? month;
  String? day;
  String? weekday;
  
  
  Future<void> getUserResponse(BuildContext context)async {
    await showDatePicker(
      context: context,
      initialDate: DateTime(2021,11,28),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    ).then((pickedDate) {
      if (pickedDate == null) {
        return;
      }
      setState(() {
        dateTime = pickedDate;
        year = dateTime!.year.toString();
        month = dateTime!.month.toString();
        day = dateTime!.day.toString();
        weekday = dateTime!.weekday.toString();
      });
      

    },
    );
    Navigator.of(context).pushNamed(
      PictureoftheDay.routeName,

    );
    print(year);
    print(month);
    print(day);
    print(weekday);
  }
  
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
        title: Text('APOD'),
        ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Container(
            alignment: Alignment.center,
            child: Text(
              'Choose the Date using the button',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(

        onPressed: ()async=>await getUserResponse(context),

        child: Icon(Icons.calendar_today,
        color: Colors.red,
        ),
      ),
    );
  }
}

  @override
  Widget build(BuildContext context) {
    // ignore: todo
    // TODO: implement build
    throw UnimplementedError();
  }